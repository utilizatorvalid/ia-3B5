import mopy.model

from mopy.model import key___Key as Key
from mopy.model import key___Note as Note
