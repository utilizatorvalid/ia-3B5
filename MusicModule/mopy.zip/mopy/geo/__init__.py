import mopy.model

from mopy.model import geo___SpatialThing as SpatialThing
