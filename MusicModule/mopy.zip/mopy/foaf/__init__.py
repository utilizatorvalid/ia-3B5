import mopy.model

from mopy.model import foaf___Agent as Agent
from mopy.model import foaf___Document as Document
from mopy.model import foaf___Group as Group
from mopy.model import foaf___Image as Image
from mopy.model import foaf___OnlineAccount as OnlineAccount
from mopy.model import foaf___OnlineChatAccount as OnlineChatAccount
from mopy.model import foaf___OnlineEcommerceAccount as OnlineEcommerceAccount
from mopy.model import foaf___OnlineGamingAccount as OnlineGamingAccount
from mopy.model import foaf___Organization as Organization
from mopy.model import foaf___Person as Person
from mopy.model import foaf___PersonalProfileDocument as PersonalProfileDocument
from mopy.model import foaf___Project as Project
