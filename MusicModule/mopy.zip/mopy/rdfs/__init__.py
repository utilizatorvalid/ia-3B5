import mopy.model

from mopy.model import rdfs___Class as Class
from mopy.model import rdfs___Resource as Resource
