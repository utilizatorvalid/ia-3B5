import mopy.model

from mopy.model import owl___Nothing as Nothing
from mopy.model import owl___Thing as Thing
